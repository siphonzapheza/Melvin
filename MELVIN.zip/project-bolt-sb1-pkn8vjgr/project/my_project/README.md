# My Project

A Django backend project with multiple applications.

## Structure

- `backend/django_app/` - Main Django application
- `backend/new_app/` - Additional Django application  
- `backend/fastapi_app/` - FastAPI application (placeholder)

## Setup

1. Navigate to the backend directory:
   ```bash
   cd my_project/backend
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Run migrations:
   ```bash
   python manage.py migrate
   ```

4. Start the development server:
   ```bash
   python manage.py runserver
   ```