"""django_app URL Configuration"""
from django.contrib import admin
from django.urls import path, include
from django_app.views.auth_views import login_page, login_view
from django_app.views.auth_views import login_page, login_view, api_login, api_logout, api_status
from django_app.views.auth_views import login_page, login_view, api_login, api_logout, api_status

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', login_page, name='login_page'),
    path('auth/login/', login_view, name='login'),
    path('api/django-app/', include('django_app.api_urls')),
    path('api/new-app/', include('new_app.urls')),
    path('', login_page, name='login_page'),
    path('auth/login/', login_view, name='login'),
    path('api/django-app/', include('django_app.api_urls')),
    path('api/new-app/', include('new_app.urls')),
    path('', login_page, name='login_page'),
    path('auth/login/', login_view, name='login'),
    path('api/django-app/', include('django_app.api_urls')),
    path('api/new-app/', include('new_app.urls')),
]