from django.urls import path
from django_app.views.auth_views import api_login, api_logout, api_status

app_name = 'django_app_api'

urlpatterns = [
    path('loginn/', api_login, name='api_login'),
    path('logout/', api_logout, name='api_logout'),
    path('status/', api_status, name='api_status'),
]