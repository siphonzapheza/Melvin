from django.urls import path
from new_app.views.test_views import test_endpoint
from new_app.views.test_views import test_endpoint
from django.urls import path
from new_app.views.test_views import test_endpoint

app_name = 'new_app'

urlpatterns = [
    path('test/', test_endpoint, name='test_endpoint'),
    path('test/', test_endpoint, name='test_endpoint'),
]